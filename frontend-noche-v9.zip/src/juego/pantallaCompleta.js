// juego/pantallaCompleta.js
// Utilidades compartidas por los juegos: detectar táctil y pasar a pantalla completa.
// Escritorio: API nativa de pantalla completa. Táctil: "modo propio" (el escenario ocupa
// toda la ventana con position: fixed), sin avisos del navegador.
import { useCallback, useEffect, useRef, useState } from 'react'

export function useTactil() {
  const [tactil, setTactil] = useState(() => typeof window !== 'undefined' && Boolean(window.matchMedia?.('(pointer: coarse)').matches))
  useEffect(() => {
    const mq = window.matchMedia?.('(pointer: coarse)')
    if (!mq) return
    const cambio = () => setTactil(mq.matches)
    mq.addEventListener?.('change', cambio)
    return () => mq.removeEventListener?.('change', cambio)
  }, [])
  return tactil
}

const elementoNativo = () => document.fullscreenElement || document.webkitFullscreenElement || null

export function usePantallaCompleta(ref) {
  const [activa, setActiva] = useState(false)
  const nativa = useRef(false)

  const desbloquear = () => {
    try {
      screen.orientation?.unlock?.()
    } catch {
      /* sin soporte */
    }
  }

  const entrar = useCallback(async () => {
    const el = ref.current
    if (!el) return
    // En teléfonos y tabletas se usa siempre el modo propio: la pantalla completa nativa de
    // Chrome Android deja un aviso ("arrastra desde arriba...") que la página no puede quitar.
    const tactil = Boolean(window.matchMedia?.('(pointer: coarse)').matches)
    const pedir = tactil ? null : el.requestFullscreen || el.webkitRequestFullscreen
    if (pedir) {
      try {
        await pedir.call(el)
        nativa.current = true
        setActiva(true)
        // En Android el navegador permite girar a horizontal estando en pantalla completa.
        try {
          await screen.orientation?.lock?.('landscape')
        } catch {
          /* escritorio o sin permiso: no pasa nada */
        }
        return
      } catch {
        /* cae al modo pseudo */
      }
    }
    nativa.current = false
    setActiva(true)
  }, [ref])

  const salir = useCallback(async () => {
    if (elementoNativo()) {
      try {
        await (document.exitFullscreen || document.webkitExitFullscreen).call(document)
      } catch {
        /* ya salió */
      }
    }
    desbloquear()
    nativa.current = false
    setActiva(false)
  }, [])

  const alternar = useCallback(() => (activa ? salir() : entrar()), [activa, entrar, salir])

  useEffect(() => {
    // Salida con Esc o con el gesto del sistema.
    const cambio = () => {
      if (nativa.current && !elementoNativo()) {
        nativa.current = false
        desbloquear()
        setActiva(false)
      }
    }
    const tecla = (e) => {
      if (e.key === 'Escape' && !nativa.current) setActiva(false)
    }
    document.addEventListener('fullscreenchange', cambio)
    document.addEventListener('webkitfullscreenchange', cambio)
    window.addEventListener('keydown', tecla)
    return () => {
      document.removeEventListener('fullscreenchange', cambio)
      document.removeEventListener('webkitfullscreenchange', cambio)
      window.removeEventListener('keydown', tecla)
    }
  }, [])

  // Bloquea el scroll de la página mientras el juego ocupa la pantalla.
  useEffect(() => {
    document.documentElement.classList.toggle('juego-fs-activo', activa)
    return () => document.documentElement.classList.remove('juego-fs-activo')
  }, [activa])

  // Si se desmonta dentro de pantalla completa, salir.
  useEffect(
    () => () => {
      if (elementoNativo()) (document.exitFullscreen || document.webkitExitFullscreen)?.call(document)
      desbloquear()
    },
    [],
  )

  return { activa, entrar, salir, alternar }
}
